import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminoperation',
  templateUrl: './adminoperation.component.html',
  styleUrls: ['./adminoperation.component.scss']
})
export class AdminoperationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
