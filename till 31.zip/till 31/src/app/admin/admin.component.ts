
import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfirmartionPop } from 'gitcloned/pms/src/app/student/student.component';


export interface PeriodicElement {
  studentId: number;
  fullName: string;
  email: string;
  mobile: number;
  status:string;
  edit: string;

}

const ELEMENT_DATA: PeriodicElement[] = [
  { studentId: 1, fullName: 'SAURABH', email: "s", mobile: 2, status:'placed',edit: 'EDIT' },
  { studentId: 2, fullName: 'ABHISHEK', email: "A", mobile: 2, status:'placed',edit: 'EDIT' },
  { studentId: 3, fullName: 'SHAKTI', email: "sH", mobile: 8, status:'placed',edit: 'EDIT' },
  { studentId: 4, fullName: 'ANKIT', email: "AN", mobile: 8, status:'placed',edit: 'EDIT' },
  { studentId: 6, fullName: 'AYUSH', email: "BH", mobile: 6, status:'placed',edit: 'EDIT' },
];
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})

export class AdminComponent {

  constructor(public pop: MatDialog) { }

  displayedColumns: string[] = ['studentId', 'fullName', 'email', 'mobile','status','edit'];
  dataSource = ELEMENT_DATA;


  editStudent() {
    console.log("edit is working");
    this.pop.open(ConfirmartionPop);

  }
  removeStudent() {
    console.log("delete is working");
  }
}




